package com.codeinfini.devoirprincipesolid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevoirPrincipeSolidApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevoirPrincipeSolidApplication.class, args);
	}

}
