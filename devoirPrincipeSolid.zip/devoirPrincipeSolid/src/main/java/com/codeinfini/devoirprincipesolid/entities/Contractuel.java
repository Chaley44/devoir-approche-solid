package com.codeinfini.devoirprincipesolid.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Contractuel extends Employe {

	private double prime;
	private double salaireNet;
	private double salaireBrut;
	private double retenu;
	private Service service;
	
	public void calculSalaire(double salaireBrut, double retenu, double prime) {
		salaireNet = salaireBrut + prime-retenu;
	}
}
