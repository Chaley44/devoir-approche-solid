package com.codeinfini.devoirprincipesolid.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Employe {

	private int id;
	private static int nombreEmploye = 0;
	private String matricule;
	private Etat etat;
	
	public Employe() {
		this.id=++nombreEmploye;
	}

	@Override
	public String toString() {
		return "Employe [id=" + id + ", matricule=" + matricule + ", etat=" + etat + "]";
	}
}
