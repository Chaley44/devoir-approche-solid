package com.codeinfini.devoirprincipesolid.entities;

public enum Etat {

	CONGE,
	ABSENT,
	MALADE;
	
}
