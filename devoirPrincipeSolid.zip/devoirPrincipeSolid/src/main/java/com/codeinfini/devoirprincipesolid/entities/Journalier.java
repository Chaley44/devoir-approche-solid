package com.codeinfini.devoirprincipesolid.entities;

public class Journalier extends Employe {

}
