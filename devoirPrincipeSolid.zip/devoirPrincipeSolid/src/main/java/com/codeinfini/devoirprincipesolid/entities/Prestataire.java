package com.codeinfini.devoirprincipesolid.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Prestataire extends Employe{

	private String periodeService;
	private double coutService;
}
