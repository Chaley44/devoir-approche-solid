package com.codeinfini.devoirprincipesolid.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Service {

	private int id;
	private static int nombreService = 0;
	private String code;
	private String nom;
	
	public Service() {
		
		this.id=++nombreService;
	}

	@Override
	public String toString() {
		return "Service [id=" + id + ", code=" + code + ", nom=" + nom + "]";
	}
	
	
}
