package com.codeinfini.devoirprincipesolid.entities;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum TypeEmploye {

	Contractuel(1)
    ,Journalier(2),
     Prestataire(3);
    private final long index;
    public static TypeEmploye getValue(int index) {
            return TypeEmploye.values()[index-1];
    }
}
