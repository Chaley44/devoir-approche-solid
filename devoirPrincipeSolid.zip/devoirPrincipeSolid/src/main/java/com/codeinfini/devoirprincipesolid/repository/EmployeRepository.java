package com.codeinfini.devoirprincipesolid.repository;

import java.util.ArrayList;
import java.util.List;

import com.codeinfini.devoirprincipesolid.entities.Employe;

public class EmployeRepository implements IEmployeRepository {

	List<Employe> employes =new ArrayList<>();
	
	@Override
	public void save(Employe employe) {
		employes.add(employe);

	}

	@Override
	public List<Employe> findByAll() {
		
		return employes;
	}

}
