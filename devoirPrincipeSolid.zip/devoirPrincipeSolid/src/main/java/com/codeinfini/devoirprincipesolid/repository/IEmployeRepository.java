package com.codeinfini.devoirprincipesolid.repository;

import java.util.List;

import com.codeinfini.devoirprincipesolid.entities.Employe;

public interface IEmployeRepository {

	void save(Employe employe);
	List<Employe> findByAll();
}
