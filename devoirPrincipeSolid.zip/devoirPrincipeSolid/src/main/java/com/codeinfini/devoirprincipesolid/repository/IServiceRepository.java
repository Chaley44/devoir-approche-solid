package com.codeinfini.devoirprincipesolid.repository;

import java.util.List;

import com.codeinfini.devoirprincipesolid.entities.Service;

public interface IServiceRepository {

	void save(Service service);
	List<Service> findByAll();
}
