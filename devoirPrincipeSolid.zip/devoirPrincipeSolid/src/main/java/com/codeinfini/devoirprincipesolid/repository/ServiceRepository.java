package com.codeinfini.devoirprincipesolid.repository;

import java.util.ArrayList;

import java.util.List;

import com.codeinfini.devoirprincipesolid.entities.Service;

public class ServiceRepository implements IServiceRepository {

	List<Service> services=new ArrayList<>();
	
	@Override
	public void save(Service service) {
		services.add(service);

	}

	@Override
	public List<Service> findByAll() {
		// TODO Auto-generated method stub
		return services;
	}

}
