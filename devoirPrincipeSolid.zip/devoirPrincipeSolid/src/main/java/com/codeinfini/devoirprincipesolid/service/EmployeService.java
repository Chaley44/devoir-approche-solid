package com.codeinfini.devoirprincipesolid.service;

import java.util.List;

import com.codeinfini.devoirprincipesolid.entities.Employe;
import com.codeinfini.devoirprincipesolid.entities.Service;
import com.codeinfini.devoirprincipesolid.repository.IEmployeRepository;
import com.codeinfini.devoirprincipesolid.repository.IServiceRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class EmployeService {
	
	private final IEmployeRepository employeRepository;
	
	public void add(Employe employe) {
		employe.setMatricule("E00"+employe.getId());
		employeRepository.save(employe);
	}
	
	public List<Employe> getAll(){
		return employeRepository.findByAll();
	}
}
