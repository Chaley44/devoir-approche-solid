package com.codeinfini.devoirprincipesolid.service;

import java.util.List;

import com.codeinfini.devoirprincipesolid.entities.Service;
import com.codeinfini.devoirprincipesolid.repository.IServiceRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class ServiceService {

	private final IServiceRepository serviceRepository;
	
	public void add(Service service) {
		service.setCode("S00"+service.getId());
		serviceRepository.save(service);
	}
	
	public List<Service> getAll(){
		return serviceRepository.findByAll();
	}
}
