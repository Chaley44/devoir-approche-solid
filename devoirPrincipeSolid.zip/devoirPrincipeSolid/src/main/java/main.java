import java.util.List;
import java.util.Scanner;

import com.codeinfini.devoirprincipesolid.entities.Contractuel;
import com.codeinfini.devoirprincipesolid.entities.Employe;
import com.codeinfini.devoirprincipesolid.entities.Journalier;
import com.codeinfini.devoirprincipesolid.entities.Prestataire;
import com.codeinfini.devoirprincipesolid.entities.Service;
import com.codeinfini.devoirprincipesolid.repository.IServiceRepository;
import com.codeinfini.devoirprincipesolid.repository.ServiceRepository;
import com.codeinfini.devoirprincipesolid.service.ServiceService;

public class main {

	 public static void main(String[] args) {
         
         IServiceRepository serviceRepository = new ServiceRepository();
         ServiceService serviceService = new ServiceService(serviceRepository);
        
         Scanner scanner=new Scanner(System.in);
         int choix;
         Service service;
         Employe employe;
         
         
         do {
            System.out.println("1-Ajouter un Service");
            System.out.println("2-Ajouter un Employe");
            System.out.println("3-Lister Les Compte");
            
            choix=scanner.nextInt();
            scanner.nextLine();
            switch (choix) {
                case 1->{
                   service=new Service(); 
                   System.out.println("Entrer le Nom du Service");
                   service.setNom(scanner.nextLine());
                   serviceService.add(service);
                   System.out.println("Liste des Services");
                   serviceService.getAll().forEach(System.out::println);
                }
                case 2->{
                    
//                     System.out.println("Entrer le Numero du client");
//                     String num=scanner.nextLine();
                	   
                	List<Service> services=serviceService.getAll();
                    if (services ==null) {
                        System.out.println("Les services n'existe pas, creer un service et revenez"); 
                     } else {
                        System.out.println("Entrer le Type du Employe");
                        System.out.println("1-Contractuel");
                        System.out.println("2-Journalier");
                        System.out.println("3-Prestataire");
                        int typeEmploye=scanner.nextInt();
                       if(typeEmploye==1){
                          employe=new Contractuel();
                        }else if(typeEmploye==2){
                          employe=new Journalier();
                        }else{
                             employe=new Prestataire();
                        }
//                        
//
                    }
                  }
                    
            
                default ->{

                }
            }
         } while (choix!=3);
         scanner.close();

    }

}
